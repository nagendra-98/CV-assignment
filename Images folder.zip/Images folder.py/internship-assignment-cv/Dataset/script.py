import cv2
img1 = cv2.imread('1.Sample-img1\fully_annotated_image.jpg', 1)
img1 = cv2.resize(img1, (600, 300))
cv2.imshow('Colored image', img1)








